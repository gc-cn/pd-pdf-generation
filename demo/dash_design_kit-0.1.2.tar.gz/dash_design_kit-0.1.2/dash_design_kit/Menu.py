# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class Menu(Component):
    """A Menu component.
A Menu displays a list of `html.A` (for absolute links),
`dcc.Link` (for fast, in-app relative links),
or `ddk.CollapsibleMenu` (a collapsible menu) components.

This component is designed to be embedded inside a `ddk.Header` or
a `ddk.Sidebar` component.

*Example Usage*

```
ddk.Header(
    logo=ddk.Logo(src='/assets/my-logo.png'),
    title='FRED Economic Indicators',
    height=80,
    children=ddk.Menu([
        ddk.CollapsibleMenu(
            title='Monetary Data',
            children=[
                dcc.Link(
                    'Monetary Base',
                    href='/monetary-base'
                ),
                dcc.Link(
                    'Money Velocity',
                    href='/money-velocity'
                ),
                dcc.Link(
                    'Reserves',
                    href='/reserves'
                ),
                dcc.Link(
                    'Borrowings',
                    href='/borrowings'
                )
            ]
        ),
        dcc.Link('Conditions', href='/conditions'),
        dcc.Link('Investment', href='/investments'),
        dcc.Link('Other', href='/other'),
    ])
)
```

Keyword arguments:
- children (a list of or a singular dash component, string or number; optional): A list of `html.A`, `dcc.Link`, or `ddk.CollapsibleMenu` components
- id (string; optional)
- className (string; optional): The className applied to the outermost container of the Menu (a nav component).
- style (dict; optional): The style applied to the outermost container of the Menu (a nav component).
- setProps (boolean | number | string | dict | list; optional): Dash-assigned callback that gets fired when the value changes."""
    @_explicitize_args
    def __init__(self, children=None, id=Component.UNDEFINED, className=Component.UNDEFINED, style=Component.UNDEFINED, **kwargs):
        self._prop_names = ['children', 'id', 'className', 'style', 'setProps']
        self._type = 'Menu'
        self._namespace = 'dash_design_kit'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['children', 'id', 'className', 'style', 'setProps']
        self.available_wildcard_properties =            []

        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(Menu, self).__init__(children=children, **args)
