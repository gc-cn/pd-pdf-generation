# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class DataCard(Component):
    """A DataCard component.
This component will render a styled DataCard with a label, large number,
sublabel. Style includes handle (with optional icon) or spark trace
if data is provided

Keyword arguments:
- id (string; optional): The ID of the component, used for Dash callbacks
- value (number; optional): The large number
- label (string; optional): The textual label that describes the label
- sub (string; optional): A smaller number to accompany `value`
- color (string; optional): Color modifies:
- The background color of the "handle". If not supplied, then this will be the accent color.
- If `trace_y` is supplied, then `color` is the color of the
  graph's line (unless `background_color` is supplied, in which case
  the trace line will be white). If `color` and `background_color`
  aren't supplied, then the color of the line will be the theme's accent
  color.
- trace_x (list; optional): The `x` data in the graph.
- trace_y (list; optional): The `y` data in the graph.
- trace_text (list; optional): The `text` data in the graph (appears on hover)
- icon (string; optional): The font awesome icon name.
This is the same as the `ddk.Icon` `icon_name` property.
- background_color (string; optional): `background_color` is only used if `trace_y` is supplied.
In which case, it will be the background color of the entire DataCard
- text_color (string; optional): The color of the text. If this isn't supplied, then
it will default to the theme's text color.
- style (dict; optional): Style overrides to the outermost container
- width (number; optional): The width (in percentage) of the component with respect to its parent.
This is the same type of unit that is used in
`Block`, `Card`, & `ControlCard`.
- margin (number; optional): Space (in pixels) surrounding the `DataCard`.
- setProps (boolean | number | string | dict | list; optional)"""
    @_explicitize_args
    def __init__(self, id=Component.UNDEFINED, value=Component.UNDEFINED, label=Component.UNDEFINED, sub=Component.UNDEFINED, color=Component.UNDEFINED, trace_x=Component.UNDEFINED, trace_y=Component.UNDEFINED, trace_text=Component.UNDEFINED, icon=Component.UNDEFINED, background_color=Component.UNDEFINED, text_color=Component.UNDEFINED, style=Component.UNDEFINED, width=Component.UNDEFINED, margin=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'value', 'label', 'sub', 'color', 'trace_x', 'trace_y', 'trace_text', 'icon', 'background_color', 'text_color', 'style', 'width', 'margin', 'setProps']
        self._type = 'DataCard'
        self._namespace = 'dash_design_kit'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'value', 'label', 'sub', 'color', 'trace_x', 'trace_y', 'trace_text', 'icon', 'background_color', 'text_color', 'style', 'width', 'margin', 'setProps']
        self.available_wildcard_properties =            []

        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(DataCard, self).__init__(**args)
