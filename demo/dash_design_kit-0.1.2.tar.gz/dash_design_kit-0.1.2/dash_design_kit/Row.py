# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class Row(Component):
    """A Row component.
The Row component is intended to wrap `Block` or `Card` components.
It will enforce equal height in these components.

`Block` and `Card` do not _need_ to be wrapped in a `Row`: only wrap
them in a `Row` if you want to force their contents to have equal height.

**Example Usage**

```
ddk.Row([
    ddk.Card(
        width=50,
        children=ddk.Graph(figure={
            'data': [{
                'x': [1, 2, 3, 4],
                'y': [5, 4, 3, 6],
                'line': {'shape': 'spline'}
            }],
            'layout': {'height': 300}
        })
    ),

    ddk.Card(
        width=50,
        children='''
        Sed ut perspiciatis unde omnis iste natus
        voluptatem accusantium doloremque laudantium,
        totam rem aperiam, eaque ipsa quae ab illo
        inventore veritatis et quasi architecto
        beatae vitae dicta sunt explicabo.
        '''
    )
])
```

See more examples in the [Blocks, Cards, and Rows](/blocks) chapter.

Keyword arguments:
- children (a list of or a singular dash component, string or number; optional)
- id (string; optional)
- style (dict; optional)
- className (string; optional)"""
    @_explicitize_args
    def __init__(self, children=None, id=Component.UNDEFINED, style=Component.UNDEFINED, className=Component.UNDEFINED, **kwargs):
        self._prop_names = ['children', 'id', 'style', 'className']
        self._type = 'Row'
        self._namespace = 'dash_design_kit'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['children', 'id', 'style', 'className']
        self.available_wildcard_properties =            []

        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(Row, self).__init__(children=children, **args)
