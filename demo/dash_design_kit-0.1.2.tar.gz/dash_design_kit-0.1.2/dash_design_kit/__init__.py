from __future__ import print_function as _

import os as _os
import sys as _sys
import json as _json

import dash as _dash

# noinspection PyUnresolvedReferences
from ._imports_ import *
from ._imports_ import __all__
from ._Markdown import _Markdown

from ._components import Card, ControlCard
from .import shortcuts
from .import datasets

if not hasattr(_dash, 'development'):
    print('Dash was not successfully imported. '
          'Make sure you don\'t have a file '
          'named \n"dash.py" in your current directory.', file=_sys.stderr)
    _sys.exit(1)

_basepath = _os.path.dirname(__file__)
_filepath = _os.path.abspath(_os.path.join(_basepath, 'package.json'))
with open(_filepath) as f:
    _package = _json.load(f)

__version__ = _package['version']

_current_path = _os.path.dirname(_os.path.abspath(__file__))

_this_module = _sys.modules[__name__]


_js_dist = [
    {
        'relative_package_path': 'dash_design_kit.min.js',
        'dev_package_path': 'dash_design_kit.dev.js',

        'namespace': "dash_design_kit"
    }
]

_css_dist = [
    {
        "relative_package_path": "normalize.css",
        "namespace": "dash_design_kit"
    },
    {
        "relative_package_path": "base.css",
        "namespace": "dash_design_kit"
    },
    {
        "relative_package_path": "editor.css",
        "namespace": "dash_design_kit"
    },
    {
        "relative_package_path": "dashboard.css",
        "namespace": "dash_design_kit"
    },
    {
        "relative_package_path": "fonts.css",
        "namespace": "dash_design_kit"
    },
]

for _component in __all__:
    setattr(locals()[_component], '_js_dist', _js_dist)
    setattr(locals()[_component], '_css_dist', _css_dist)
