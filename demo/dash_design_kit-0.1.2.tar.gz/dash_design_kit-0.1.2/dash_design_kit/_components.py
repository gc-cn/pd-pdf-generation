# -*- coding: utf-8 -*-
import copy
import random
import string
import dash_core_components as dcc
import dash_dangerously_set_inner_html
import dash_html_components as html
import dash_design_kit as ddk
import os

from ._utils import _merge, _omit, _relative_width, _id_not_accepted

with open(os.path.join(
    os.path.dirname(__file__), 'images', 'fullscreen.svg')
) as f:
    fullscreen_svg = f.read()

with open(os.path.join(
    os.path.dirname(__file__), 'images', 'modal.svg')
) as f:
    modal_svg = f.read()


@_id_not_accepted
def ControlCard(
        controls=None,
        orientation='vertical',
        label_position='top',
        label_text_alignment='left',
        control_position='left',
        padding=10,
        wrap=True,
        style={},
        **card_kwargs
    ):
    """
    `ControlCard` is used to render controls and their labels.

    ```
    app.layout = ddk.App([
        ddk.ControlCard(width=30, controls=[
            {
                'label': 'Engine',
                'control': dcc.Dropdown(
                    options=[
                        {'label': i, 'value': i}
                        for i in ['Rear', 'Front', 'Side']
                    ],
                    multi=True,
                    value=['Rear']
                ),
            },
            {
                'label': 'Thrusters',
                'control': dcc.Slider(
                    min=0,
                    max=10,
                    marks={
                        0: '0',
                        3: '3',
                        5: '5',
                        7.65: '7.65 °F',
                        10: '10'
                    },
                    value=5
                ),
            },
            {
                'label': 'Power',
                'control': dcc.Input(
                    value=50,
                    type='number'
                ),
            }
        ]),

        ddk.Card(width=70, children=ddk.Graph(figure={
            'data': [{
                'x': [1, 2, 3, 4],
                'y': [4, 1, 6, 9],
                'line': {'shape': 'spline'}
            }]
        }))
    ])
    ```

    **Keyword Arguments**
    - `controls` - A list of dicts describing the control and its label. Each dict has the keys:
        - `label` - The label of the control
        - `control` - A `dcc` control element like `dcc.Dropdown`, `dcc.Input`, `dcc.DatePickerSingle` or `htmlButton`
        - `width` (optional) - The width of the control/label pair, from 0 to 100.
    - `orientation` (`'vertical'` or `'horizontal'`) - The orientation of the set of controls
    - `label_position` (`'top'`, `'left'`, `'bottom'`, `'right'`) - The positon of the label with respect to the control
    - `label_text_alignment` (`left` or `'right'`) - The horizontal label text alignment
    - `control_position` (`'left'`, `'right'`, or `'center'`)
    - `padding` (Number) - The padding between the edge of the card and the content
    - `wrap` (boolean) - If there are more than 5 controls, whether or not they should wrap onto the next line or stay in a single line
    - `style` (style dict)
    - `**card_kwargs` - `ControlCard` renders the controls within a `Card`. `card_kwargs` includes any extra parameters to `Card` (e.g. `type`)

    """
    def getControlStyle(width, orientation, height, padding, wrap):
        controlStyle = { 'padding': '{}px'.format(padding) }
        if height is not None:
            controlStyle['height'] = _relative_width(height, 0)
        if orientation == 'vertical':
            controlStyle['width'] = _relative_width(width, 0)
        else:
            flexBasis = _relative_width(width, 0)
            if wrap == False:
                flexBasis = 'auto'
            controlStyle['flex'] = '1 0 ' + flexBasis,
            if width is not None:
                controlStyle['max-width'] = _relative_width(width, 0)
        return controlStyle


    if not isinstance(controls, list):
        controls = [controls]

    labelInControls = any('label' in dict for dict in controls)

    default_label = ""

    if (labelInControls and orientation=='horizontal'):
        default_label = '\u200b' # zero-width space placeholder

    wrapStyle = {
        'flex-wrap': ('wrap' if wrap==True and orientation =='horizontal' else 'nowrap'),
        'flex-direction': ('column' if orientation=='vertical' else None),
    }

    control_card_class = 'controls ' + orientation + ' ' + control_position
    control_class = 'control'
    default_width = None
    if orientation=='vertical':
        control_class += ' control--vertical'
        default_width = 1
    if label_position=='top':
        control_class += ' label--top'
    elif label_position == 'bottom':
        control_class += ' label--bottom'
    elif label_position == 'right':
        control_class += ' label--right'
    control_class += ' label--text--' + label_text_alignment
    return Card(
        style=_merge(wrapStyle, style),
        control_card_class=control_card_class,
        children=[
            html.Div(
                [
                    (html.Div(i.get('label',default_label), className="control--label")),
                    html.Div(i.get('control',None), className="control--item")
                ] if 'control' in i else i,
                className=control_class,
                style=(getControlStyle(
                    i.get('width', default_width),
                    orientation,
                    i.get('height', 'initial'),
                    padding, wrap
                ) if 'control' in i else None)
            )
            for i in controls
            ],
        **card_kwargs
    )


@_id_not_accepted
def Card(children=None, title=None,
         type='shadow', control_card_class=None, shadow_weight='light',
         card_hover=False, modal=False, modal_config=None, fullscreen=False,
         control=None, control_position="top", rounded=False, width=100,
         margin=15, padding=5, style={}, **kwargs):
    """
    `Card` is a styled `Block`.

    **Example Usage**
    ```
    ddk.Card(
        width=30,
        title='Example Card',
        children=ddk.Graph(
            id='graph',
            figure={
                'data': [{
                    'y': [1, 2, 3]
                }]
            }
        )
    )
    ```

    **Arguments**
    - `children`
    - `title` (string or Dash component; optional)
    - `type` (`'shadow'`, `'color'`, `'simple-border'`, or `'flat'`)
    - `shadow_weight` (`'light'`, `'medium'`, or `'heavy'`)
    - `card_hover` (boolean)
    - `modal` (boolean). Allows the card to be expanded to a modal.
    - `modal_config` Dict. Takes 'width' and 'height' arguments to define modal dimensions.
    - `fullscreen` (boolean). Allows the card to be expanded to fullscreen.
    - `control` - A `dcc.Control` component like `dcc.Dropdown`
    - `control_position` (`'top'` or `'bottom'`)
    - `rounded` (boolean)
    - `width` (Number between 0 and 100): 100 takes up 100% of the parent's width.
    - `margin` (Number). Represents space on the outside of the card.
    - `padding` (Number). Represents the space between the card's border and its content
    - `style` - Dict. CSS styles passed in to the Card's outermost container.
    """
    card_header = None
    card_footer = None
    control_below = None
    expand_modal_icon = None
    expand_fullscreen_icon = None
    fullscreen_modal_icon = None
    if fullscreen or modal:
        card_id = 'expandable-' + ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(5))
        kwargs['id'] = card_id
    if fullscreen:
        expand_modal_icon = ddk.FullScreen(
            children=[
                html.Div(dash_dangerously_set_inner_html.DangerouslySetInnerHTML(fullscreen_svg))
            ],
            target_id=card_id
        )
    if modal:
        expand_fullscreen_icon = ddk.Modal(
            children=[
                html.Div(dash_dangerously_set_inner_html.DangerouslySetInnerHTML(modal_svg))
            ],
            target_id=card_id,
            width = (modal_config['width'] if modal_config and modal_config['width'] else None),
            height = (modal_config['height'] if modal_config and modal_config['height'] else None)
        )
    if title:
        card_header = html.Div(
            className='card-header' + (' control' if control is not None and control_position == "top" else ''),
            children=[
                html.B(title, style={'display': 'inline-flex', 'flex': '1', 'align-items': 'center'}),
                (html.Div(
                    style={
                        'flex': '1'
                    },
                    className="control-in-card_container",
                    children=control
                ) if control is not None and control_position == "top" else None),
                expand_modal_icon,
                expand_fullscreen_icon
            ]
        )
    elif not title and control is not None and control_position == "top":
        card_header = html.Div(
            className='control card-header card-header_no-title',
            children=[
                html.Div(
                    style={
                        'flex': '1'
                    },
                    className="control-in-card_container",
                    children=control
                ),
                html.Div(
                    style={
                        'display': 'flex'
                    },
                    children=[
                        expand_modal_icon,
                        expand_fullscreen_icon
                    ]
                )
            ]
        )
    elif fullscreen or modal:
        card_header = html.Div(
            className='card-header card-header_no-title',
            children=[
                html.Div(
                    style={
                        'display': 'flex',
                        'margin-left': 'auto'
                    },
                    children=[
                        expand_modal_icon,
                        expand_fullscreen_icon
                    ]
                )
            ]
        )

    if control is not None and control_position == "below":
        control_below = html.Div(
            className='control control-below',
            children=[
                html.Div(
                    style={
                        'flex': '1'
                    },
                    className="control-in-card_container",
                    children=control
                )
            ]
        )

    if control is not None and control_position == "bottom":
        card_footer = html.Div(
            className='control card-footer',
            children=[
                html.Div(
                    style={
                        'flex': '1'
                    },
                    className="control-in-card_container",
                    children=control
                )
            ]
        )

    card_style = ({
        'shadow': {},
        'color':'var(--text)',
        'simple-border': {
            'border': 'thin var(--border) solid',
        },
        'flat': {}
    })[type]

    card_class = 'card'
    if type == 'shadow':
        if shadow_weight == 'light':
            card_class += ' card-box-shadow-light'
        if shadow_weight == 'medium':
            card_class += ' card-box-shadow-medium'
        if shadow_weight == 'heavy':
            card_class += ' card-box-shadow-heavy'
    if card_hover:
        card_class += ' card-box-shadow-hover'

    if rounded:
        if rounded == True:
            card_style['borderRadius'] = 5
        else:
            card_style['borderRadius'] = rounded

    content_style = {
        'padding': padding,
    }

    content_class = 'card--content'
    if control_card_class:
        content_class += ' ' + control_card_class

    return ddk.Block(
        style=_merge(card_style, content_style, style),
        className=card_class,
        width=width,
        padding=padding,
        margin=margin,
        children=[
            card_header,
            control_below,
            html.Div(
                children,
                style=_merge(content_style, style),
                className=content_class
            ),
            card_footer
        ],
        **kwargs
    )
