import os as _os

# Package up the datasets in ddk that are used in documenation
# or in sample apps, enabling our end users to easily run the examples

def _read_csv(filename, **pd_kwargs):
    import pandas as _pd
    return _pd.read_csv(_os.path.join(
        _os.path.dirname(__file__),
        'datasets',
        filename
    ), **pd_kwargs)

# meaningful datasets
gapminder = lambda: _read_csv('gapminder.csv')
us_cities = lambda: _read_csv('2014_us_cities.csv', skipinitialspace=True)
flight_delays = lambda: _read_csv('flights-3m.csv')
flight_traffic = lambda: _read_csv('airport_traffic.csv')

df_streamtube = lambda: _read_csv('streamtube-basic.csv')
df_choropleth = lambda: _read_csv('choropleth-world.csv')
df_scattergeo = lambda: _read_csv('scattergeo.csv')
df_iris = lambda: _read_csv('iris.csv')

tickers = {
    'DEXUSEU': lambda: _read_csv('DEXUSEU.csv'),
    'INDPRO': lambda: _read_csv('INDPRO.csv'),
    'UNRATE': lambda: _read_csv('UNRATE.csv'),
    'IC4WSA': lambda: _read_csv('IC4WSA.csv'),
}

# mock datasets that look good for particular graphs
timeseries = lambda: _read_csv('timeseries.csv')

def bubble():
    import pandas as _pd
    return _pd.DataFrame({
        'x1': gapminder()[0:500]['lifeExp'],
        'y1': gapminder()[0:500]['gdpPercap'],
        'size1': gapminder()[0:500]['pop'],
        'color1': gapminder()[0:500]['year'],

        'x2': gapminder()[-500:-1]['gdpPercap'],
        'y2': gapminder()[-500:-1]['lifeExp'],
        'size2': gapminder()[-500:-1]['pop'],
        'color2': gapminder()[-500:-1]['year'],
    })
